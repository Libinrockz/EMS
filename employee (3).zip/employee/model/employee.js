const mongoose = require('mongoose');
const Schema  = mongoose.Schema;

//creating schema & from schema we will create a  model
const employeeSchema = new Schema({
    fullname : {type:String, required: true},
    email : {type: String, required: true},
    position: {type: String, required: true},
    department: {type: mongoose.Types.ObjectId, required: true, ref:'department'},
    dateOfBirth: {type: Date, required: true},
    dateOfJoining: {type: Date, required: true},
    salary: {type: Number, required: true}
})

module.exports = mongoose.model('employee', employeeSchema)