const mongoose = require('mongoose');
const Schema  = mongoose.Schema;

//creating schema & from schema we will create a  model
const departmentSchema = new Schema({
    name : {type:String, required: true, unique:true},
    employees: [{type: mongoose.Types.ObjectId, required:true, ref:'employee'}]
    
})

module.exports = mongoose.model('department', departmentSchema)