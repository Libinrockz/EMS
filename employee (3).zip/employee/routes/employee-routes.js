
const express = require('express');
const httpError  = require('../model/http-error');

//create a router object to handle routes or path
const router = express.Router();
const employeeControllers = require('../controllers/employee-controllers')
const {check} = require('express-validator')

router.get('/employees',employeeControllers.employeeList);
router.get('/:empid', employeeControllers.getEmpById);
router.post('/',[check('fullname').notEmpty().isLength({min:3}),
    check('email').isEmail().notEmpty(),
    check('department').notEmpty(),
    check('dateOfBirth').isDate().notEmpty(),
    check('dateOfJoining').isDate().notEmpty(),
    check('salary').notEmpty()], employeeControllers.createEmployee);
router.patch('/:empid', employeeControllers.updateEmployee);
router.delete('/:empid', employeeControllers.deleteEmployee);


module.exports = router