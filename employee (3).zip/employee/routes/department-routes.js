
const express = require('express');
const httpError  = require('../model/http-error');

//create a router object to handle routes or path
const router = express.Router();
const departmentControllers = require('../controllers/department-controllers')
const {check} = require('express-validator')

router.get('/departments',departmentControllers.departmentList);
router.get('/:depid', departmentControllers.getDepById);
router.post('/',[check('name').notEmpty().isLength({min:3})], departmentControllers.createDepartment);
router.patch('/:depid', departmentControllers.updateDepartment);
router.delete('/:depid', departmentControllers.deleteDepartment);


module.exports = router