//starting point of our application
const express = require('express');
const bodyParser = require('body-parser');
const app = express();




const employeeroutes = require('./routes/employee-routes');
const departmentroutes = require('./routes/department-routes');


const mongoose = require('mongoose')
app.use(bodyParser.json());
app.use('/api/employee',employeeroutes);
app.use('/api/department',departmentroutes);

//middleware to handle unimplemented routes or path
app.use((req,res,next)=>{
    const error = new HttpError('could not find this route',404);
    throw error;
  
  });
  
  app.use((err, req, res, next) => {
      //if the response is sent it will pass to another middleware
      if(res.headerSent){
          return next(err)
      }
      res.status(err.code || 500);
      res.json({message: err.message} || 'An unkown error occured')
      // console.error(err.stack)
      // res.status(500).send('Something broke!')
    })
  

mongoose.connect('mongodb+srv://libinrockz21:1xFjv02guDFARAoQ@faith.l9ehq.mongodb.net/edms?retryWrites=true&w=majority&appName=faith').then(()=>{

//to start the server 
app.listen(5000);
}).catch(err=>{
    console.log(err);
})



