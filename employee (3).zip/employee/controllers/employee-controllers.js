const express = require('express');
const httpError  = require('../model/http-error');
const {v4 : uuidv4} = require('uuid');
const { validationResult} = require('express-validator');
const HttpError = require('../model/http-error');

const Employee = require('../model/employee');
const employee = require('../model/employee');
const Department = require('../model/department');
const mongoose= require('mongoose');



const employeeList = async (req,res,next)=>{
    let employee;
    try {
        employee = await Employee.find();
    }catch(err){
        const error = new HttpError('No Employee list',500);
        return next(error);
    }

    res.json({employee: employee.map(employee=>employee.toObject({getters:true}))});
}


const getEmpById = async (req,res,next)=>{
    const id = req.params.empid;
    let employee;
    try{
        employee = await Employee.findById(id);
    }catch(err){
        const error = new HttpError('something went wrong, could not find a employee',500);
        return next(error);
    }
    if(!employee){
        const error = new httpError('could not find a employee with given id',404);
        return next(error);

    }
    //converting id to string: toObject({getters:true})
    res.json({employee:employee.toObject({getters:true})})

}

const createEmployee = async (req,res,next)=>{
    const errors = validationResult(req);
    if(!errors.isEmpty()){
        console.log(errors);
        const error = new HttpError('Invalid inputs... please check your data',422)
        return next(error);

    }
    const {fullname, email, position,department, dateOfBirth, dateOfJoining, salary} = req.body;
    let existingEmployee;
    try{
        existingEmployee = await Employee.findOne({email:email});    
    }
    catch(err){
        const error = new HttpError('Creation Failed, Please Try Again', 500);
        return next(error);
    }
    if(existingEmployee){
        const error = new HttpError('Employee With Email Already Exists !!', 422);
        return next(error);
    }
    const createEmployee = new Employee({
        fullname: fullname,
        email: email,
        position: position,
        department: department,
        dateOfBirth: dateOfBirth,
        dateOfJoining: dateOfJoining,
        salary: salary,
    })
    let existingdepartment;
    try{
        existingdepartment = await Department.findById(department);
    }catch(err){
        const error = new HttpError('Employee Creation Failed',500);
        return next(error);
    }
    if(!existingdepartment){
        const error = new HttpError('Could Not Find Department,Try Again',500);
        return next(error);
    }
    try{
        const sess = await mongoose.startSession();
        sess.startTransaction();
        await createEmployee.save({session:sess})
        existingdepartment.employees.push(createEmployee);
        await existingdepartment.save({session:sess})
        await sess.commitTransaction();
    }catch(err){
        console.log(err)
        const error = new HttpError('Adding Employee Failed',500);
        return next(error);
    }
    res.status(201).json({employee: createEmployee});

}

const updateEmployee = async (req,res,next)=>{
    const {department} = req.body;
    const empid = req.params.empid;

    let employee;
    try{
        employee = await Employee.findById(empid);
    }catch(err){
        const error = new HttpError('update gone wrong',500);
        return next(error);
    }
    employee.department = department;
    try{
        employee.save();
    }catch(err){
        const error = new HttpError('something gone wrong',500);
        return next(error);
    }
    res.status(200).json({employee:employee.toObject({getters:true})});

}

const deleteEmployee = async (req,res,next)=>{
    const empid = req.params.empid;

    let employee;
    try {
        employee = await Employee.findById(empid).populate('department');
    }catch(err){
        console.log(err)
        const error = new HttpError('Something went wrong while deleting the employee',500);
        return next(error);
    }
    if(!employee){
        const error = new HttpError('Could Not Find A Employee With Given Id',404)
        return next(error);
    }
    try{
        const sess = await mongoose.startSession();
        sess.startTransaction()
        await employee.deleteOne({session:sess});
        employee.department.employees.pull(employee)
        await employee.department.save({session:sess})
        await sess.commitTransaction()
    }catch(err){
        console.log(err)
        const error = new HttpError('Something Went Wrong,Could Not Delete Employee',500)
        return next(error);
    }
    
    res.status(200).json({message:'Employee deleted successfully'});
}

exports.employeeList = employeeList;
exports.createEmployee = createEmployee;
exports.getEmpById = getEmpById;
exports.updateEmployee = updateEmployee;
exports.deleteEmployee = deleteEmployee;