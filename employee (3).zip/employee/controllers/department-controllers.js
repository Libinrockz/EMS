const express = require('express');
const httpError  = require('../model/http-error');
const {v4 : uuidv4} = require('uuid');
const { validationResult} = require('express-validator');
const HttpError = require('../model/http-error');

const Department = require('../model/department');


const departmentList = async (req,res,next)=>{
    let department;
    try {
        department = await Department.find();
    }catch(err){
        const error = new HttpError('No department list',500);
        return next(error);
    }
    res.status(201).json({department: department.map(department=>department.toObject({getters:true}))});
}


const getDepById = async (req,res,next)=>{
    const id = req.params.depid;
    let department;
    try{
        department = await Department.findById(id);
    }catch(err){
        const error = new HttpError('something went wrong, could not find a department',500);
        return next(error);
    }
    if(!department){
        throw new httpError('could not find a department with given id',404)
    }
    //converting id to string: toObject({getters:true})
    res.status(201).json({department:department.toObject({getters:true})})

}

const createDepartment = async (req,res,next)=>{
    const errors = validationResult(req);
    if(!errors.isEmpty()){
        console.log(errors);
        throw new HttpError('Invalid inputs... please check your data',422)
    }
    const {name} = req.body;
    let existingDepartment;
    try{
        existingDepartment = await Department.findOne({name:name});
    }catch(err){
        const error = new HttpError(' creating department failed...',500);
        return next(error);
    }
    if (existingDepartment){
        const error = new HttpError('Department already exist! create a new one..',422);
        return next(error); 
    }
    const createDepartment = new Department({
        name: name,
        employees:[]
    })
    try{
        await createDepartment.save();
    }catch(err){
        const error = new HttpError('creating department failed',500);
        return next(error);
    }
    res.status(201).json({department: createDepartment});

}

const updateDepartment = async (req,res,next)=>{
    const {name} = req.body;
    const depid = req.params.depid;

    let department;
    try{
        department = await Department.findById(depid);
    }catch(err){
        const error = new HttpError('update gone wrong',500);
        return next(error);
    }
    department.name = name;
    try{
        department.save();
    }catch(err){
        const error = new HttpError('something gone wrong',500);
        return next(error);
    }
    res.status(200).json({department:department.toObject({getters:true})});

}

const deleteDepartment = async (req,res,next)=>{
    const depid = req.params.depid;

    let department;
    try {
        department = await Department.deleteOne({ _id:depid});
    }catch(err){
        const error = new HttpError('Something went wron while deleting the department',500);
        return next(error);
    }
    if(!department){
        throw new HttpError('Could Not Find A Department With Given Id',404)
    }
    res.status(200).json({message:'department deleted successfully'});
}

exports.departmentList = departmentList;
exports.createDepartment = createDepartment;
exports.getDepById = getDepById;
exports.updateDepartment = updateDepartment;
exports.deleteDepartment = deleteDepartment;
